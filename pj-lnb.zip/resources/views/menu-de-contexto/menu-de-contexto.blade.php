@push("estilo-menu-de-contexto")
<link rel="stylesheet" href="{{asset('css/menu-de-contexto.css')}}">
@endpush

@section("section-menu-de-contexto")
<div id="context-menu">
    <div class="item item-botao-excluir-menu-contexto">Excluir Coluna</div>
</div>
@endsection