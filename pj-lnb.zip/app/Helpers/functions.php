<?php

// namespace App\Helpers;

// class Functions
// {
//     private $cml;

//     public function get_conteudo_modal_largo () {
//         return $this->cml;
//     }
//     public function set_conteudo_modal_largo ($par) {
//         $this->cml = $par;
//     }
// }



// [...] //


function muda_conteudo_modal_edit_conforme_pagina () {
    $request_uri = $_SERVER["REQUEST_URI"];

    if ($request_uri == "/estoque/produto") {
            
    }
}
?>