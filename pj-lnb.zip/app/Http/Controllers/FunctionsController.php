<?php
namespace App\Http\Controllers;

class FunctionsController {
    public function index () {
        return view("app");
    }
}